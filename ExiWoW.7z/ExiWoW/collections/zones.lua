ExiWoW.LibAssets.zones = {};
local f = ExiWoW.LibAssets.zones

f["sandy"] = {}
f["sandy"]["Durotar"] = true;
f["sandy"]["Burning Steppes"] = true;
f["sandy"]["Tanaris"] = true;
f["sandy"]["Westfall"] = true;
f["sandy"]["Barrens"] = true;
f["sandy"]["Stonetalon Mountains"] = true;
f["sandy"]["Thousand Needles"] = true;
f["sandy"]["Desolace"] = true;
f["sandy"]["Searing Gorge"] = true;
f["sandy"]["Badlands"] = true;
f["sandy"]["Blasted Lands"] = true;
f["sandy"]["Deadwind pass"] = true;
f["sandy"]["Hellfire Peninsula"] = true;
f["sandy"]["Blade's Edge Mountains"] = true;
f["sandy"]["Netherstorm"] = true;
f["sandy"]["Shadowmoon Valley"] = true;




